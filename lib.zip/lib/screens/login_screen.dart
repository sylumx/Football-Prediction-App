import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'register_screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController emailController = TextEditingController();
    final TextEditingController passwordController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
        backgroundColor: Colors.indigo,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              child: const Text('Login'),
              onPressed: () async {
                try {
                  debugPrint('Login button pressed');
                  final authProvider =
                      Provider.of<AuthProvider>(context, listen: false);
                  debugPrint(
                      'Attempting login with email: ${emailController.text}');
                  final success = await authProvider.login(
                    emailController.text,
                    passwordController.text,
                  );
                  debugPrint('Login result: $success');
                  if (success) {
                    debugPrint(
                        'Login successful, navigating to predictions screen');
                    Navigator.pushReplacementNamed(context, '/predictions');
                  } else {
                    debugPrint('Login failed, showing snackbar');
                    debugPrint(
                        'Error message: ${authProvider.loginErrorMessage}');
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(authProvider.loginErrorMessage)),
                    );
                  }
                } catch (e) {
                  debugPrint('Login error in UI: $e');
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error: ${e.toString()}')),
                  );
                }
              },
            ),
            const SizedBox(height: 16),
            TextButton(
              child: const Text('Don\'t have an account? Register'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const RegisterScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
