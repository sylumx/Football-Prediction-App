class Prediction {
  final String homeTeam;
  final String awayTeam;
  final String homeTeamLogo;
  final String awayTeamLogo;
  final DateTime date;
  final String leagueName;
  final String leagueCountry;
  final String betType;
  final double recommendedOdd;
  final double confidenceLevel;
  final String? weather;
  final String? venue;
  final double? predictedHomeScore;
  final double? predictedAwayScore;

  Prediction({
    required this.homeTeam,
    required this.awayTeam,
    required this.homeTeamLogo,
    required this.awayTeamLogo,
    required this.date,
    required this.leagueName,
    required this.leagueCountry,
    required this.betType,
    required this.recommendedOdd,
    required this.confidenceLevel,
    this.weather,
    this.venue,
    this.predictedHomeScore,
    this.predictedAwayScore,
  });

  factory Prediction.fromJson(Map<String, dynamic> json) {
    return Prediction(
      homeTeam: json['home_team'] ?? '',
      awayTeam: json['away_team'] ?? '',
      homeTeamLogo: json['home_team_logo'] ?? '',
      awayTeamLogo: json['away_team_logo'] ?? '',
      date: DateTime.parse(json['fixture_date'] ?? json['date']),
      leagueName: json['league_name'] ?? '',
      leagueCountry: json['league_country'] ?? '',
      betType: json['bet_type'] ?? '',
      recommendedOdd: (json['recommended_odd'] as num?)?.toDouble() ?? 0.0,
      confidenceLevel: (json['confidence_level'] as num?)?.toDouble() ?? 0.0,
      weather: json['weather'],
      venue: json['fixture']?['venue']?['name'] ?? 'Unknown',
      predictedHomeScore: (json['predicted_home_score'] as num?)?.toDouble(),
      predictedAwayScore: (json['predicted_away_score'] as num?)?.toDouble(),
    );
  }

  String get predictedScore {
    if (predictedHomeScore == null || predictedAwayScore == null) {
      return 'N/A';
    }
    return '${predictedHomeScore!.toStringAsFixed(1)} - ${predictedAwayScore!.toStringAsFixed(1)}';
  }
}
