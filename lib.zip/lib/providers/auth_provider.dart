import 'package:flutter/foundation.dart';
import '../services/auth_service.dart';

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  bool _isLoggedIn = false;
  Map<String, dynamic>? _userData;
  String _loginErrorMessage = '';

  bool get isLoggedIn => _isLoggedIn;
  Map<String, dynamic>? get userData => _userData;
  String get loginErrorMessage => _loginErrorMessage;

  AuthProvider() {
    _checkLoginStatus();
  }

  Future<bool> login(String email, String password) async {
    debugPrint('AuthProvider: login method called');
    final result = await _authService.login(email, password);
    debugPrint('AuthProvider: login result: ${result['success']}');
    if (result['success']) {
      debugPrint('AuthProvider: Login successful, checking login status');
      _isLoggedIn = true;
      _userData = result['data'];
      _loginErrorMessage = '';
    } else {
      debugPrint('AuthProvider: Login failed, setting isLoggedIn to false');
      _isLoggedIn = false;
      _userData = null;
      _loginErrorMessage = result['message'];
    }
    notifyListeners();
    return result['success'];
  }

  Future<void> _checkLoginStatus() async {
    final userInfo = await _authService.getUserInfo();
    if (userInfo != null) {
      _isLoggedIn = true;
      _userData = userInfo;
    } else {
      _isLoggedIn = false;
      _userData = null;
    }
    notifyListeners();
  }

  Future<bool> register(String name, String email, String password,
      String phoneNumber, String countryCode, String countryName) async {
    final success = await _authService.register(
        name, email, password, phoneNumber, countryCode, countryName);
    if (success) {
      await _checkLoginStatus();
    }
    return success;
  }

  Future<Map<String, dynamic>?> getUserInfo() async {
    return await _authService.getUserInfo();
  }

  Future<void> logout() async {
    try {
      await _authService.logout();
      _isLoggedIn = false;
      _userData = null;
      notifyListeners();
    } catch (e) {
      debugPrint('Error during logout: $e');
      // You might want to handle the error here, e.g., show an error message to the user
    }
  }

  Future<void> refreshUserData() async {
    await _checkLoginStatus();
  }
}
