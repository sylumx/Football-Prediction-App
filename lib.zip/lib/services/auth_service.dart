import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class TempStorage {
  static final Map<String, String> _storage = {};

  static Future<void> setString(String key, String value) async {
    _storage[key] = value;
    debugPrint('TempStorage: Stored $key with value: $value');
  }

  static Future<String?> getString(String key) async {
    final value = _storage[key];
    debugPrint('TempStorage: Retrieved $key with value: $value');
    return value;
  }

  static Future<void> remove(String key) async {
    _storage.remove(key);
    debugPrint('TempStorage: Removed $key');
  }
}

class AuthService {
  final String baseUrl = 'https://footballprediction.site/api';
  final String defaultApiToken =
      'OrXJ8JQOQEkWNzWxKQCl41LavnjptYmHaodInge93ceba470';

  Future<String> _getApiToken() async {
    final storedToken = await TempStorage.getString('api_token');
    final token = storedToken ?? defaultApiToken;
    debugPrint('AuthService: Using API token: $token');
    return token;
  }

  Future<Map<String, String>> _getHeaders() async {
    final apiToken = await _getApiToken();
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer $apiToken',
    };
  }

  Future<bool> register(String name, String email, String password,
      String phoneNumber, String countryCode, String countryName) async {
    try {
      final headers = await _getHeaders();
      final response = await http.post(
        Uri.parse('$baseUrl/register'),
        headers: headers,
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
          'password_confirmation': password,
          'phoneNumber': phoneNumber,
          'countryCode': countryCode,
          'countryName': countryName,
          'terms': true,
        }),
      );

      if (response.statusCode == 201) {
        debugPrint('AuthService: Registration successful');
        return true;
      } else if (response.statusCode == 422) {
        final errors = jsonDecode(response.body)['errors'];
        throw Exception(errors.values.join('\n'));
      }
      return false;
    } catch (e) {
      rethrow;
    }
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      final headers = await _getHeaders();
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: headers,
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      );

      final responseBody = jsonDecode(response.body);

      if (response.statusCode == 200) {
        debugPrint('AuthService: Login successful, storing user data');
        await TempStorage.setString('user_data', response.body);
        // Do not store any new token or override the existing one
        return {'success': true, 'data': responseBody};
      } else {
        return {
          'success': false,
          'message': responseBody['message'] ?? 'Login failed',
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'An error occurred during login'};
    }
  }

  Future<void> logout() async {
    try {
      final headers = await _getHeaders();
      final response = await http.post(
        Uri.parse('$baseUrl/logout'),
        headers: headers,
      );

      debugPrint('AuthService: Logout response status: ${response.statusCode}');
      await TempStorage.remove('user_data');
      await TempStorage.remove(
          'api_token'); // Only if you intend to log out completely
    } catch (e) {
      rethrow;
    }
  }

  Future<Map<String, dynamic>?> getUserInfo() async {
    try {
      final headers = await _getHeaders();
      final response = await http.get(
        Uri.parse('$baseUrl/user/profile'),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data;
      } else {
        debugPrint(
            'AuthService: Failed to get user info. Status code: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      debugPrint('AuthService: Error getting user info: $e');
      return null;
    }
  }
}
