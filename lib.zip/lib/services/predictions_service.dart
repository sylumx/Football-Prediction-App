import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class PredictionsService {
  final String baseUrl = 'https://footballprediction.site/api';
  final String apiToken = 'OrXJ8JQOQEkWNzWxKQCl41LavnjptYmHaodInge93ceba470';

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $apiToken',
      };

  Future<Map<String, dynamic>?> fetchPredictions() async {
    try {
      debugPrint('Attempting to fetch predictions');
      debugPrint('Headers being sent: $_headers');

      final response = await http.get(
        Uri.parse('$baseUrl/predictions'),
        headers: _headers,
      );

      debugPrint('Fetch Predictions request URL: ${response.request?.url}');
      debugPrint('Fetch Predictions response status: ${response.statusCode}');
      debugPrint('Fetch Predictions response body: ${response.body}');

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else if (response.statusCode == 401) {
        debugPrint('Authentication failed. Please check your API token.');
        // You might want to trigger a re-authentication process here
        return null;
      } else {
        debugPrint(
            'Failed to fetch predictions. Status code: ${response.statusCode}');
        debugPrint('Response body: ${response.body}');
        return null;
      }
    } catch (e) {
      debugPrint('Fetch Predictions Error: $e');
      debugPrint('Fetch Predictions Error Stack Trace: ${StackTrace.current}');
      return null;
    }
  }
}
